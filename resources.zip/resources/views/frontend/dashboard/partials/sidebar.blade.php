<div class="static-sidebar-wrapper sidebar-default">
    <div class="static-sidebar">
        <div class="sidebar">
            <div class="widget stay-on-collapse" id="widget-sidebar">

                <nav role="navigation" class="widget-body">
                    <ul class="acc-menu">
                        <li><a href="{{ route('dashboard') }}"><i class="fa fa-home"></i><span>Dashboard</span></a></li>
                        <li><a href="{{ route('dashboard.settings') }}"><i class="fa fa-cogs"></i><span>User Settings</span></a></li>
                        <li><a href="javascript:;"><i class="fa fa-pencil"></i><span>Forms</span></a>
                            <ul class="acc-menu">
                                <li><a href=" {{ route('press.create') }}">Press</a></li>
                                <li><a href="#">Leading role</a></li>
                                <li><a href="#">Major significance</a></li>
                                <li><a href="#">Critical role</a></li>
                                <li><a href="#">High compensation</a></li>
                                <li><a href="#">Major commercial success</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>

            </div>
        </div>
    </div>
</div>